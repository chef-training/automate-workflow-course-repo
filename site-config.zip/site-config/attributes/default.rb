default['site-config']['company-name'] = 'Chef Software, Inc.'
default['site-config']['project-name'] = 'Automate Demo'
